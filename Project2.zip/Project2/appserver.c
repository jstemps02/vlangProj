#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <string.h>
#include <stdio.h>
#include "Bank.c"
#include <sys/time.h>

struct trans { // structure for a transaction pair
    int acc_id; // account ID
    int amount; // amount to be added, could be positive or negative

};

struct request {
    struct request * next; // pointer to the next request in the list
    int request_id;     // request ID assigned by the main thread
    int check_acc_id; // account ID for a CHECK request
    struct trans * transactions; // array of transaction data
    int num_trans;     // number of accounts in this transaction
    struct timeval starttime, endtime; // starttime and endtime for TIME
};

struct queue {
    struct request * head, * tail; // head and tail of the list
    int num_jobs; // number of jobs currently in queue
};

char* outputFile;
int exitVar = 0;
char * fixedArg[20];
struct timeval current_time;
pthread_mutex_t mainLock;
pthread_mutex_t fileLock;
pthread_cond_t condition;
FILE *filePointer;


void writer(char * outputFile, char * str){
    pthread_mutex_lock(&fileLock);
   // fwrite(str, 1, sizeof(str), filePointer);
    fprintf(filePointer,"%s",str);
    pthread_mutex_unlock(&fileLock);
}

char** argListFix(char *com, char *arg){
    int y = 0;
	int x = 0;
    int l = 0;
	
    for(l =0;l < 20; l++){
		fixedArg[l] = (char *) malloc (25);
	}
	
	char * token = strtok(arg, " ");
	for(x = 0; x < strlen(com); x++){
		fixedArg[0][x] = com[x];
	}
	y++;
	while(token != NULL){
		for(x = 0; x < strlen(token); x++){
			fixedArg[y][x] = token[x];
		}
		token = strtok(NULL, " ");
		y++;
	}
	if(strcmp(arg, "\n") == 0){
		y--;
	}
	fixedArg[y] = NULL;
	int a = 0;
    return fixedArg;
    free(fixedArg);

}

struct queue q;

void* queueHelper(void * data){
    struct timeval end;
    char * printVar;
    printVar = malloc(152);
    pthread_mutex_lock(&mainLock);

    if(q.num_jobs == 0){
        pthread_cond_wait(&condition, &mainLock);
    }
    
    struct request * holder;
    holder = malloc(sizeof(struct request));

            if(q.num_jobs == 1){
                holder = q.head;
                q.head = NULL;
                q.tail = NULL;
                q.num_jobs = 0;
            }
            else{
                holder = q.head;
                struct request* temp = q.head;
                q.head = temp->next;
                q.tail = q.tail;
                q.num_jobs = q.num_jobs - 1;
            }
            pthread_mutex_unlock(&mainLock);
            
            if(holder->check_acc_id == -1 && holder->transactions != NULL){//it is TRANS
                int i;
                int bal;
                int ISF;
                int accountID;
                ISF = 0;
                struct trans transact; 
                
                for(i = 0; i < holder->num_trans; i++){
                    transact = holder->transactions[i];
                    bal = read_account(transact.acc_id);
                    if((bal + transact.amount) < 0){
                        ISF = 1;
                        accountID = transact.acc_id;
                        break;
                    }
                }
                if(ISF == 0){
                    for(i = 0; i < holder->num_trans; i++){
                        transact = holder->transactions[i];
                        bal = read_account(transact.acc_id);
                        bal = bal + transact.amount;
                        write_account(transact.acc_id, bal);
                    }
                    gettimeofday(&end, NULL);
                    sprintf(printVar, "%d OK TIME %ld.%06.ld %ld.%06.ld\n", holder->request_id, holder->starttime.tv_sec, holder->starttime.tv_usec, end.tv_sec, end.tv_usec);
                }
                else{
                    gettimeofday(&end, NULL);
                    sprintf(printVar, "%d ISF %d TIME %ld.%06.ld %ld.%06.ld\n", holder->request_id, accountID, holder->starttime.tv_sec, holder->starttime.tv_usec, end.tv_sec, end.tv_usec);
                }
                
            }
            else if(holder->check_acc_id != -1 && holder->transactions == NULL){//it is CHECK
                int val;
                struct timeval time;
                val = read_account(holder->check_acc_id);
                gettimeofday(&end, NULL);
                sprintf(printVar, "%d BAL %d TIME %ld.%06.ld %ld.%06.ld\n", holder->request_id, read_account(holder->check_acc_id), holder->starttime.tv_sec, holder->starttime.tv_usec, end.tv_sec, end.tv_usec);

            }
            else{
                sprintf(printVar, "ERROR\n");
            }

            // printf("req_id: %d\n", holder->request_id);
            // printf("acc_id: %d\n", holder->check_acc_id);
            // printf("transactions: %d\n", holder->transactions);
            // printf("num_trans: %d\n", holder->num_trans);
            // printf("start: %d\n", holder->starttime);
            // printf("end: %d\n", holder->endtime);
            pthread_mutex_lock(&mainLock);
            writer(outputFile, printVar);
            pthread_mutex_unlock(&mainLock);
            free(holder->transactions);
            free(printVar);
    
}

int main(int argc, char **argv) {
    
    char command[30];
    char args[30];
    char *p;
    int rc;
    int interator;
    interator = 0;
    pthread_t thid;
    int numAccounts;
    int numThreads;
    struct request *head,*req;
    head = NULL;

    pthread_mutex_init(&mainLock, NULL);
    pthread_mutex_init(&fileLock, NULL);
    gettimeofday(&current_time, NULL);
  //  printf("TIME %ld.%06ld\n", current_time.tv_sec, current_time.tv_usec);

    if(argc > 4){ //too many arguments
         printf("Too many arguments\n");
        return 0;
    }
    if(argc < 4){ //too few arguments
          printf("Too few arguments\n");
          return 0;
    }
    else{
        int i;
        int errorCode;
        numAccounts = strtol(argv[2], &p, 10);
        numThreads = strtol(argv[1], &p, 10);
        
        for(i = 0; i<numThreads ;i++){
            rc = pthread_create(&thid, NULL, queueHelper, &numThreads);
            if(rc != 0) {
                perror("pthread_create() error");
                exit(1);
            }
        }
        pthread_mutex_t mutArray[numAccounts]; //mutex array for storing the mutexes for each account.
        
        outputFile = argv[3];
        filePointer = fopen(outputFile,"w+");

        initialize_accounts(numAccounts);
        while(exitVar == 0){
            req = malloc(sizeof(struct request));

            // req->next=NULL;
            // head = req;

			fscanf(stdin, "%s", command); //get input

			fgets(args, 100, stdin);
            
            if(strcmp(command, "END") == 0){
             //   printf("END DETECTED\n");
                exitVar = 1;
                exit(1);
                break;
            }
            else if(strcmp(command, "CHECK") == 0){
                int val = atoi(args);
                req->request_id = interator;
                req->check_acc_id = val;
                req->transactions = NULL;
                req->num_trans = 0;
                gettimeofday(&current_time, NULL);
                req->starttime = current_time;
                req->endtime = current_time;
             //   printf("CHECK DETECTED\n");
            }
            else if(strcmp(command, "TRANS") == 0){
                char ** fixedArg;
                fixedArg = argListFix(command, args);
                int x;
                int y;
                y = 0;
                struct trans* transArr;
                transArr = malloc(sizeof(transArr) * 10);

                for(x = 1; x <= 21; x++){
                    if(fixedArg[x] == '\0'){
                        transArr[x/2].acc_id = -1;
                        transArr[x/2].amount = -1;
                        break;
                    }
                    else{
                       // printf("x: %d\n", x);

                        transArr[x/2].acc_id = atoi(fixedArg[x]);
                        transArr[x/2].amount = atoi(fixedArg[x + 1]);
                        // printf("Line:%d || %s\n",x, fixedArg[x]);
                        // printf("Line:%d || %s\n",x + 1, fixedArg[x + 1]);
                        y++;
                        x++;
                        
                    }
                    //printf("num of trans: %d\n", (y));
                }
                req->request_id = interator;
                req->check_acc_id = -1;
                req->transactions = transArr;
                req->num_trans = y;
                gettimeofday(&current_time, NULL);
                req->starttime = current_time;
                req->endtime = current_time;               
              //  printf("TRANS DETECTED\n");
            } 

            // printf("req_id: %d\n", req->request_id);
            //printf("acc_id: %d\n", req->check_acc_id);
            // printf("transactions: %d\n", req->transactions);
            // printf("num_trans: %d\n", req->num_trans);
            // printf("start: %d\n", req->starttime);
            // printf("end: %d\n", req->endtime);

            //printf("before lock\n");
            pthread_mutex_lock(&mainLock); //lock
            if(head == NULL){
                q.head = req;
                q.tail = req;
                q.num_jobs = 1;
            }
            else{
                struct request* temp = q.tail;
                temp->next = req;
                q.tail = temp;
                q.tail = req;
                q.num_jobs = q.num_jobs + 1;
            }
            interator++;
            pthread_mutex_unlock(&mainLock);//unlock
            pthread_cond_signal(&condition);
            //printf("after lock\n");
            
        }


        fclose(filePointer);
        pthread_mutex_destroy(&mainLock);
        pthread_mutex_destroy(&fileLock);
        free_accounts();
    }
        

}